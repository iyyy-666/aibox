from __future__ import annotations

from dataclasses import dataclass
import math


Box = tuple[int, int, int, int]


def _center(box: Box) -> tuple[float, float]:
    x, y, width, height = box
    return x + width / 2.0, y + height / 2.0


def _iou(first: Box, second: Box) -> float:
    ax, ay, aw, ah = first
    bx, by, bw, bh = second
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    union = aw * ah + bw * bh - intersection
    return intersection / union if union else 0.0


@dataclass(frozen=True)
class TrackingConfig:
    deadband_ratio: float = 0.07
    smoothing_alpha: float = 0.35
    control_interval_sec: float = 0.10
    lost_timeout_sec: float = 0.50
    max_degrees_per_second: float = 20.0
    pwm_per_degree: float = 11.11
    min_step_pwm: int = 4
    max_step_pwm: int = 22
    pitch_min_step_pwm: int | None = None
    pitch_max_step_pwm: int | None = None
    pwm_min: int = 500
    pwm_max: int = 2500
    yaw_sign: int = 1
    pitch_sign: int = 1


@dataclass(frozen=True)
class TrackingDecision:
    yaw_delta_pwm: int = 0
    pitch_delta_pwm: int = 0
    state: str = "idle"
    offset_x: float = 0.0
    offset_y: float = 0.0


class PalmTargetLock:
    def __init__(self, iou_threshold: float = 0.15) -> None:
        self.iou_threshold = iou_threshold
        self.box: Box | None = None

    def arm(self, boxes: list[Box], image_size: tuple[int, int]) -> Box | None:
        if not boxes:
            self.box = None
            return None
        image_width, image_height = image_size
        target_x, target_y = image_width / 2.0, image_height / 2.0
        self.box = min(boxes, key=lambda box: (_center(box)[0] - target_x) ** 2 + (_center(box)[1] - target_y) ** 2)
        return self.box

    def update(self, boxes: list[Box]) -> Box | None:
        if self.box is None:
            return None
        matched = [box for box in boxes if _iou(self.box, box) >= self.iou_threshold]
        if not matched:
            if len(boxes) != 1:
                return None
            previous_center = _center(self.box)
            candidate_center = _center(boxes[0])
            center_distance = math.hypot(
                candidate_center[0] - previous_center[0],
                candidate_center[1] - previous_center[1],
            )
            motion_limit = 1.25 * max(*self.box[2:], *boxes[0][2:])
            if center_distance > motion_limit:
                return None
            self.box = boxes[0]
            return self.box
        self.box = max(matched, key=lambda box: _iou(self.box or box, box))
        return self.box

    def clear(self) -> None:
        self.box = None


class PalmTrackingController:
    def __init__(self, config: TrackingConfig | None = None) -> None:
        self.config = config or TrackingConfig()
        self.active = False
        self._last_seen_at: float | None = None
        self._last_command_at: float | None = None
        self._smooth_x = 0.0
        self._smooth_y = 0.0
        self.yaw_sign = self.config.yaw_sign
        self.pitch_sign = self.config.pitch_sign

    def start(self, box: Box, now: float) -> None:
        self.active = True
        self._last_seen_at = now
        self._last_command_at = now
        self._smooth_x = 0.0
        self._smooth_y = 0.0

    def stop(self) -> None:
        self.active = False
        self._last_seen_at = None
        self._last_command_at = None
        self._smooth_x = 0.0
        self._smooth_y = 0.0

    def update(self, box: Box | None, image_size: tuple[int, int], now: float) -> TrackingDecision:
        if not self.active:
            return TrackingDecision()
        if box is None:
            if self._last_seen_at is not None and now - self._last_seen_at >= self.config.lost_timeout_sec:
                return TrackingDecision(state="lost")
            return TrackingDecision(state="waiting")

        self._last_seen_at = now
        width, height = image_size
        center_x, center_y = _center(box)
        offset_x = (center_x - width / 2.0) / max(1.0, width / 2.0)
        offset_y = (center_y - height / 2.0) / max(1.0, height / 2.0)
        alpha = min(1.0, max(0.0, self.config.smoothing_alpha))
        self._smooth_x = (
            0.0
            if abs(offset_x) <= self.config.deadband_ratio
            else alpha * offset_x + (1.0 - alpha) * self._smooth_x
        )
        self._smooth_y = (
            0.0
            if abs(offset_y) <= self.config.deadband_ratio
            else alpha * offset_y + (1.0 - alpha) * self._smooth_y
        )

        last_command_at = self._last_command_at if self._last_command_at is not None else now
        elapsed = max(0.0, now - last_command_at)
        if elapsed < self.config.control_interval_sec:
            return TrackingDecision(state="waiting", offset_x=self._smooth_x, offset_y=self._smooth_y)

        yaw = self._axis_delta(self._smooth_x, elapsed, self.yaw_sign)
        pitch = self._axis_delta(
            self._smooth_y,
            elapsed,
            self.pitch_sign,
            min_step_pwm=self.config.pitch_min_step_pwm,
            max_step_pwm=self.config.pitch_max_step_pwm,
        )
        self._last_command_at = now
        if yaw == 0 and pitch == 0:
            return TrackingDecision(state="centered", offset_x=self._smooth_x, offset_y=self._smooth_y)
        return TrackingDecision(yaw, pitch, "tracking", self._smooth_x, self._smooth_y)

    def observe_feedback(self, *, offset_x: float, offset_y: float) -> tuple[bool, bool]:
        del offset_x, offset_y
        return False, False

    def _axis_delta(
        self,
        offset: float,
        elapsed: float,
        sign: int,
        *,
        min_step_pwm: int | None = None,
        max_step_pwm: int | None = None,
    ) -> int:
        if abs(offset) <= self.config.deadband_ratio:
            return 0
        minimum = self.config.min_step_pwm if min_step_pwm is None else min_step_pwm
        maximum = self.config.max_step_pwm if max_step_pwm is None else max_step_pwm
        proportional = round(abs(offset) * maximum)
        step = max(minimum, proportional)
        permitted = int(self.config.max_degrees_per_second * self.config.pwm_per_degree * elapsed)
        limit = min(maximum, max(minimum, permitted))
        step = min(step, limit)
        if step == 0:
            return 0
        return step * (1 if offset > 0 else -1) * (1 if sign >= 0 else -1)
