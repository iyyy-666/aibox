from __future__ import annotations

import importlib.util
import math
import os
import sys
import threading
import time
from dataclasses import asdict, dataclass, is_dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

import numpy as np

from ..resources import DEFAULT_DEVICE_PATHS, ensure_distinct_actuator_devices


@dataclass(frozen=True, slots=True)
class LegacyVisionSpec:
    filename: str
    class_name: str
    mode: str


LEGACY_VISION_SPECS = {
    "object_sorting": LegacyVisionSpec("sorting_app.py", "SortingApp", "sorting"),
    "plate_recognition": LegacyVisionSpec("plate_recognition_app.py", "PlateRecognitionApp", "plate"),
    "palm_recognition": LegacyVisionSpec("palm_recognition_app.py", "PalmRecognitionApp", "palm"),
    "palm_tracking": LegacyVisionSpec("palm_tracking_app.py", "PalmTrackingApp", "tracking"),
    "fruit_recognition": LegacyVisionSpec("fruit_recognition_app.py", "FruitRecognitionApp", "fruit"),
    "color_recognition": LegacyVisionSpec("color_recognition_app.py", "ColorRecognitionApp", "color"),
    "face_detection": LegacyVisionSpec("face_recognition_app.py", "FaceRecognitionApp", "face"),
    "shape_recognition": LegacyVisionSpec("shape_recognition_app.py", "ShapeRecognitionApp", "shape"),
}

PLATE_RESULT_HOLD_SECONDS = float(os.getenv("PLATE_RESULT_HOLD_SECONDS", "10.0"))
PLATE_DETECT_INTERVAL_SECONDS = float(os.getenv("PLATE_DETECT_INTERVAL_SECONDS", "0.5"))
FRUIT_RESULT_HOLD_SECONDS = float(os.getenv("FRUIT_RESULT_HOLD_SECONDS", "5.0"))


def _load_legacy_module(spec: LegacyVisionSpec, legacy_root: str | Path) -> ModuleType:
    root = Path(legacy_root)
    path = root / spec.filename
    if not path.is_file():
        raise RuntimeError(f"找不到原功能算法文件：{path}")
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    module_name = f"feature_demo_legacy_{path.stem}"
    module_spec = importlib.util.spec_from_file_location(module_name, path)
    if module_spec is None or module_spec.loader is None:
        raise RuntimeError(f"无法加载原功能算法：{path}")
    module = importlib.util.module_from_spec(module_spec)
    sys.modules[module_name] = module
    module_spec.loader.exec_module(module)
    return module


def _plain_value(value: Any) -> Any:
    if is_dataclass(value):
        data = asdict(value)
    elif hasattr(value, "__dict__"):
        data = vars(value)
    elif isinstance(value, tuple):
        return [_plain_value(item) for item in value]
    else:
        return value
    clean = {}
    for key, item in data.items():
        if key in {"contour"}:
            continue
        if isinstance(item, tuple):
            clean[key] = list(item)
        elif isinstance(item, (str, int, float, bool)) or item is None:
            clean[key] = item
    return clean


class LegacyVisionAdapter:
    def __init__(self, module_id: str, module: ModuleType, instance: object, spec: LegacyVisionSpec) -> None:
        self.module_id = module_id
        self.module = module
        self.instance = instance
        self.spec = spec
        self._last_control_at = 0.0
        self._sorting_observer = None
        self._tracking_lock = threading.RLock()
        self._tracking_generation = 0
        self._last_plate_detections = []
        self._last_plate_detected_at = 0.0
        self._next_plate_detection_at = 0.0
        self._last_plate_frame_at = 0.0
        self._last_fruit_detections = []
        self._last_fruit_detected_at = 0.0
        self._next_fruit_detection_at = 0.0
        self._last_fruit_frame_at = 0.0
        self._fruit_detection_interval = max(
            0.0, float(getattr(module, "DETECT_INTERVAL_SEC", 0.18))
        )

    def set_sorting_observer(self, observer) -> None:
        self._sorting_observer = observer

    def process(self, frame):
        mode = self.spec.mode
        if mode == "sorting":
            normal, _ = self.module.split_stereo(frame)
            detected = self.instance._detect_color(normal)
            if self._sorting_observer is not None:
                self._sorting_observer(None if detected is None else detected[0])
            annotation_frame = self._sorting_annotation_frame(normal)
            annotated = self.instance._annotate(annotation_frame, detected)
            return self._single_camera_view(annotated, normal), {"result": _plain_value(detected)}
        if mode == "tracking":
            return self._process_tracking(frame)

        normal = self.instance._normal_frame(frame)
        if mode == "color":
            detections = self.instance._detect_colors(normal)
            stable_filter = getattr(self.module, "stable_filter", None)
            if callable(stable_filter):
                detections, self.instance._stable_signatures = stable_filter(
                    self.instance._stable_signatures,
                    detections,
                    label_fn=lambda item: item.name,
                    box_fn=lambda item: (item.box[0], item.box[1], item.box[0] + item.box[2], item.box[1] + item.box[3]),
                    image_shape=normal.shape,
                    stable_hits=self.module.STABLE_HITS,
                )
        elif mode == "shape":
            raw = self.instance._detect_shapes(normal)
            self.instance._last_raw_count = len(raw)
            detections = self.instance._stabilize(raw)
        elif mode == "fruit":
            now = time.monotonic()
            if self._last_fruit_frame_at > 0.0:
                frame_interval = now - self._last_fruit_frame_at
                if frame_interval > 0.0:
                    self.instance.fps = 1.0 / frame_interval
            self._last_fruit_frame_at = now
            detections = list(self._last_fruit_detections)
            if now >= self._next_fruit_detection_at:
                detections = (
                    self.instance._detect_fruits(normal)
                    if self.instance.model is not None
                    else []
                )
                now = time.monotonic()
                self._next_fruit_detection_at = now + self._fruit_detection_interval
                if detections:
                    self._last_fruit_detections = list(detections)
                    self._last_fruit_detected_at = now
            if not detections and now - self._last_fruit_detected_at <= FRUIT_RESULT_HOLD_SECONDS:
                detections = list(self._last_fruit_detections)
            elif not detections:
                self._last_fruit_detections = []
        elif mode == "plate":
            now = time.monotonic()
            if self._last_plate_frame_at > 0.0:
                frame_interval = now - self._last_plate_frame_at
                if frame_interval > 0.0:
                    self.instance.fps = 1.0 / frame_interval
            self._last_plate_frame_at = now
            if getattr(self.instance, "_plate_model_initialized", True) is False:
                self.instance._load_model()
                self.instance._plate_model_initialized = True
            detections = list(self._last_plate_detections)
            if now >= self._next_plate_detection_at:
                recognition_frame = self._normalized_plate_frame(normal)
                detections = self.instance._recognize_plates(recognition_frame)
                if not detections:
                    preview = self.instance._annotate(normal, [])
                    preview_frame = self._normalized_plate_frame(preview)
                    detections = self.instance._recognize_plates(preview_frame)
                self._next_plate_detection_at = now + PLATE_DETECT_INTERVAL_SECONDS
                if detections:
                    self._last_plate_detections = list(detections)
                    self._last_plate_detected_at = now
                elif now - self._last_plate_detected_at <= PLATE_RESULT_HOLD_SECONDS:
                    detections = list(self._last_plate_detections)
                else:
                    self._last_plate_detections = []
            if (
                self._last_plate_detections
                and now - self._last_plate_detected_at > PLATE_RESULT_HOLD_SECONDS
            ):
                self._last_plate_detections = []
                detections = []
        elif mode == "face":
            detections = self.instance._detect_dnn(normal)
            if not detections:
                detections = self.instance._detect_yunet(normal)
            if not detections:
                detections = self.instance._detect_haar(normal)
        elif mode == "palm":
            left, right = self.module.split_stereo(frame)
            detections = self.instance._detect_hands(left, right)
            normal = (
                right
                if getattr(self.instance, "_last_detection_eye", "left") == "right"
                else left
            )
        else:
            raise RuntimeError(f"未知的视觉适配模式：{mode}")
        annotated = self.instance._annotate(normal, detections)
        result = {"result": [_plain_value(item) for item in detections]}
        if mode == "fruit":
            result["model_loaded"] = self.instance.model is not None
            result["recognition_status"] = getattr(
                self.instance, "_last_status", ""
            )
            result["model_classes"] = dict(
                getattr(self.instance, "model_names", {})
            )
        if mode == "plate":
            result["recognition_debug"] = getattr(self.instance, "_last_lpr_debug", "")
            result["recognition_status"] = getattr(self.instance, "_last_status", "")
        return annotated, result

    def _process_tracking(self, frame):
        with self._tracking_lock:
            tracking_action = None
            generation = self._tracking_generation
            left, right = self.module.split_stereo(frame)
            selected = left
            observations = self.instance.hand_detector.detect(left)
            if not observations:
                observations = self.instance.right_hand_detector.detect(right)
                if observations:
                    selected = right
            self.instance.image_size = (selected.shape[1], selected.shape[0])
            boxes = [item.box for item in observations]
            self.instance.current_landmarks = getattr(observations[0], "landmarks", None) if observations else None
            if self.instance.tracking_enabled:
                self.instance.current_box = self.instance.target_lock.update(boxes)
            else:
                self.instance.current_box = boxes[0] if boxes else None
            now = time.monotonic()
            if (
                generation == self._tracking_generation
                and self.instance.tracking_enabled
                and self.instance.current_box is not None
                and now - self._last_control_at
                >= self.module.CONTROL_INTERVAL_MS / 1000.0
            ):
                decision = self.instance.controller.update(
                    self.instance.current_box, self.instance.image_size, now
                )
                if decision.state == "tracking":
                    ok, detail = self.instance.gimbal.move(
                        decision.yaw_delta_pwm,
                        decision.pitch_delta_pwm,
                        self.module.CONTROL_INTERVAL_MS,
                    )
                    if not ok:
                        self._pause_tracking_locked()
                        raise RuntimeError(f"云台通信失败：{detail}")
                    tracking_action = {
                        "state": "moved",
                        "yaw_delta_pwm": decision.yaw_delta_pwm,
                        "pitch_delta_pwm": decision.pitch_delta_pwm,
                    }
                self._last_control_at = now
            annotated = self.instance._annotate(selected, self.instance.current_box)
            result = {
                "result": "已检测到手掌" if self.instance.current_box else "未检测到手掌",
                "tracking": self.instance.tracking_enabled,
            }
            if tracking_action is not None:
                result["tracking_action"] = tracking_action
            return annotated, result

    def manual_gimbal_step(self, step: Callable[[], dict]) -> dict:
        with self._tracking_lock:
            resume_tracking = self.instance.tracking_enabled
            self._pause_tracking_locked()
            self.instance.gimbal.disconnect()
            result = step()
            if result.get("ok") is True:
                if not self.instance.gimbal.reload_position():
                    return {
                        "ok": False,
                        "message": "云台已移动，但位置同步失败，请重新开始跟踪。",
                    }
            if resume_tracking and result.get("ok") is True:
                box = self.instance.current_box
                if box is not None:
                    locked = self.instance.target_lock.arm(
                        [box], self.instance.image_size
                    )
                    if locked is not None:
                        self.instance.current_box = locked
                        self.instance.controller.start(locked, time.monotonic())
                        self._tracking_generation += 1
                        self.instance.tracking_enabled = True
            return result

    @staticmethod
    def _sorting_annotation_frame(normal):
        if len(getattr(normal, "shape", ())) < 2:
            return normal
        return np.concatenate((normal, normal), axis=1)

    @staticmethod
    def _single_camera_view(annotated, normal):
        """Keep the sorting preview on one eye if legacy annotation returns stereo."""
        annotated_shape = getattr(annotated, "shape", ())
        normal_shape = getattr(normal, "shape", ())
        if len(annotated_shape) >= 2 and len(normal_shape) >= 2:
            width = normal_shape[1]
            if annotated_shape[1] > width:
                return annotated[:, :width].copy()
        return annotated

    def _normalized_plate_frame(self, frame):
        cv2_module = getattr(self.module, "cv2", None)
        imencode = getattr(cv2_module, "imencode", None)
        imdecode = getattr(cv2_module, "imdecode", None)
        if not callable(imencode) or not callable(imdecode):
            return frame
        try:
            ok, encoded = imencode(
                ".jpg",
                frame,
                [int(cv2_module.IMWRITE_JPEG_QUALITY), 84],
            )
            if not ok:
                return frame
            normalized = imdecode(encoded, cv2_module.IMREAD_COLOR)
            return frame if normalized is None else normalized
        except Exception:
            return frame

    def command(self, name: str, payload: dict) -> dict:
        if self.spec.mode == "tracking":
            if name == "start_tracking":
                with self._tracking_lock:
                    box = self.instance.current_box
                    if box is None:
                        return {"ok": False, "message": "请先将手掌放入画面。"}
                    locked = self.instance.target_lock.arm([box], self.instance.image_size)
                    if locked is None:
                        return {"ok": False, "message": "手掌目标未能锁定。"}
                    self.instance.current_box = locked
                    self.instance.controller.start(locked, time.monotonic())
                    self._tracking_generation += 1
                    self.instance.tracking_enabled = True
                    return {"ok": True, "message": "已开始手掌跟踪。"}
            if name == "stop_tracking":
                self.stop_tracking()
                return {"ok": True, "message": "已停止手掌跟踪。"}
        if name == "save_snapshot":
            return {"ok": False, "message": "截图由统一界面保存。"}
        raise ValueError(f"不支持的视觉命令：{name}")

    def stop_tracking(self) -> None:
        if self.spec.mode != "tracking":
            return
        with self._tracking_lock:
            self._pause_tracking_locked()
            self.instance.gimbal.disconnect()

    def _pause_tracking_locked(self) -> None:
        self._tracking_generation += 1
        self.instance.tracking_enabled = False
        self.instance.target_lock.clear()
        self.instance.controller.stop()

    def close(self) -> None:
        if self.spec.mode == "tracking":
            self.stop_tracking()
            self.instance.gimbal.disconnect()
        hand_detector = getattr(self.instance, "hand_detector", None)
        close = getattr(hand_detector, "close", None)
        if callable(close):
            close()
        right_hand_detector = getattr(self.instance, "right_hand_detector", None)
        close = getattr(right_hand_detector, "close", None)
        if callable(close):
            close()


def _initialize_instance(module: ModuleType, spec: LegacyVisionSpec) -> object:
    legacy_class = getattr(module, spec.class_name)
    instance = legacy_class.__new__(legacy_class)
    instance.fps = 0.0
    instance.det_fps = 0.0
    instance._last_status = ""
    instance._set_status = lambda text: setattr(instance, "_last_status", str(text))
    mode = spec.mode
    if mode in {"color", "shape", "fruit", "plate"}:
        instance._stable_signatures = {}
    if mode == "shape":
        instance._last_raw_count = 0
    elif mode == "fruit":
        instance.model = None
        instance.cls_model = None
        instance.model_names = {}
        instance.cls_names = {}
        instance.fruit_class_ids = set(module.FALLBACK_FRUIT_CLASS_IDS)
        instance._load_model()
    elif mode == "plate":
        instance.catcher = None
        instance.fallback_catcher = None
        instance._last_lpr_debug = "not run"
        instance._plate_model_initialized = False
    elif mode == "face":
        instance.dnn = instance._load_dnn()
        instance.yunet = instance._load_yunet()
        cv2_module = getattr(module, "cv2", None)
        instance.face_detectors = (
            instance._load_cascades()
            if callable(getattr(cv2_module, "CascadeClassifier", None))
            else []
        )
    elif mode == "palm":
        instance.use_mediapipe = module.USE_MEDIAPIPE
        instance.hand_detector = module.HandLandmarkDetector()
        instance.right_hand_detector = module.HandLandmarkDetector()
        instance._tracker = module.BoxTracker(hold_misses=module.HOLD_MISSES)
        instance._voter = module.TemporalGestureVote(confirm_hits=module.STABLE_HITS, hold_misses=module.HOLD_MISSES)
    elif mode == "tracking":
        min_step_pwm = int(os.getenv("PALM_TRACK_MIN_STEP_PWM", "4"))
        max_step_pwm = int(os.getenv("PALM_TRACK_MAX_STEP_PWM", "22"))
        config = module.TrackingConfig(
            deadband_ratio=float(os.getenv("PALM_TRACK_DEADBAND_RATIO", "0.07")),
            smoothing_alpha=float(os.getenv("PALM_TRACK_SMOOTHING_ALPHA", "0.35")),
            control_interval_sec=module.CONTROL_INTERVAL_MS / 1000.0,
            lost_timeout_sec=float(os.getenv("PALM_TRACK_LOST_TIMEOUT_SEC", "0.5")),
            max_degrees_per_second=float(os.getenv("PALM_TRACK_MAX_DEGREES_PER_SECOND", "80")),
            pwm_per_degree=float(os.getenv("PALM_TRACK_PWM_PER_DEGREE", "11.11")),
            min_step_pwm=min_step_pwm,
            max_step_pwm=max_step_pwm,
            pitch_min_step_pwm=min_step_pwm,
            pitch_max_step_pwm=max_step_pwm,
            yaw_sign=int(os.getenv("PALM_TRACK_YAW_SIGN", "-1")),
            pitch_sign=int(os.getenv("PALM_TRACK_PITCH_SIGN", "-1")),
        )
        instance.controller = module.PalmTrackingController(config)
        instance.target_lock = module.PalmTargetLock()
        gimbal_port = os.getenv(
            "PALM_TRACK_SERIAL_PORT",
            "/dev/serial/by-id/usb-1a86_USB_Single_Serial_5C67040336-if00",
        )
        ensure_distinct_actuator_devices(
            {"robot": DEFAULT_DEVICE_PATHS["robot"], "gimbal": (gimbal_port,)}
        )
        instance.gimbal = module.SerialGimbalClient(
            port=gimbal_port,
            baud=int(os.getenv("PALM_TRACK_SERIAL_BAUD", "115200")),
            yaw_id=int(os.getenv("PALM_TRACK_YAW_ID", "1")),
            pitch_id=int(os.getenv("PALM_TRACK_PITCH_ID", "2")),
            pwm_min=int(os.getenv("PALM_TRACK_PWM_MIN", "500")),
            pwm_max=int(os.getenv("PALM_TRACK_PWM_MAX", "2500")),
            initial_pwm=int(os.getenv("PALM_TRACK_INITIAL_PWM", "1500")),
            min_pitch_move_pwm=min_step_pwm,
        )
        instance.hand_detector = module.HandLandmarkDetector()
        instance.right_hand_detector = module.HandLandmarkDetector()
        instance.tracking_enabled = False
        instance.current_box = None
        instance.current_landmarks = None
        instance.image_size = (module.CAMERA_WIDTH // 2, module.CAMERA_HEIGHT)
    elif mode == "sorting":
        instance.paused = False
        instance.action_busy = False
        instance.candidate_color = ""
        instance.candidate_count = 0
    return instance


def build_vision_adapter(module_id: str, *, legacy_root: str | Path | None = None) -> LegacyVisionAdapter:
    try:
        spec = LEGACY_VISION_SPECS[module_id]
    except KeyError as exc:
        raise ValueError(f"未知的视觉功能：{module_id}") from exc
    root = legacy_root or os.getenv("AIBOX_LEGACY_ROOT", "/root/robot_arm")
    module = _load_legacy_module(spec, root)
    instance = _initialize_instance(module, spec)
    return LegacyVisionAdapter(module_id, module, instance, spec)
