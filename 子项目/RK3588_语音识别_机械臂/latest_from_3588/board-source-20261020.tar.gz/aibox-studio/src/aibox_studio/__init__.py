"""AIBox Studio student application."""

